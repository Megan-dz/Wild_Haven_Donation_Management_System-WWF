# 🐾 Wild Haven — Wildlife Conservation Donation Website

> **A simple digital platform that helps people support wildlife conservation in India.**

## 🌿 About the Website

Wild Haven is a donation website created to make supporting wildlife conservation simple and transparent.

Visitors can:

- Learn about Wild Haven's mission
- See how different donation amounts can support conservation
- Explore individual campaigns
- Choose a donation amount
- Make a one-time or monthly donation
- Complete a demo payment using Card or UPI / QR
- Find answers to common donor questions

---

## 🔄 How the Website Works

**1. Explore** → Learn about Wild Haven and its mission.

**2. See the impact** → Understand what different donations can support.

**3. Choose a campaign** → For example, support snow leopard conservation.

**4. Donate** → Select one-time/monthly and choose an amount.

**5. Payment** → Continue to Card or UPI / QR payment.

**6. Learn more** → Use the FAQ to answer common donor questions.

---

## 💰 Donation Options

The website provides preset donation amounts:

**₹500 · ₹1,000 · ₹2,500 · ₹5,000 · ₹10,000 · ₹25,000**

Users can also enter a custom amount.

Example impact options include:

| Donation | Example |
|---|---|
| ₹1,000 | Guard a Snow Leopard |
| ₹5,000 | Rescue an Elephant |
| ₹25,000 | Restore One Acre |

---

## ✨ Main Features

- 🐅 Wildlife conservation campaigns
- 🌳 Mission and impact information
- 💰 One-time & monthly donations
- ✏️ Custom donation amount
- 💳 Card payment interface
- 📱 UPI / QR payment option
- 📊 Campaign progress tracking
- ❓ FAQ section
- 🎨 Simple, nature-focused design

---

## 🖼️ Website Preview

### Home & Donation

![Wild Haven Homepage](images/home.png)

### Our Mission

![Wild Haven Mission](images/mission.png)

### Where Your Gift Goes

![Wild Haven Impact](images/impact.png)

### Campaign Page

![Snow Leopard Campaign](images/campaign.png)

### Payment

![Wild Haven Payment](images/payment.png)

### FAQ

![Wild Haven FAQ](images/faq.png)

---

## ⚠️ Note

The current payment page is a **demo checkout**. No real payment is processed.

---

## 🎓 Academic Project

This website was created as part of an academic project on **digital information systems and donation management**.

The project demonstrates how a digital platform can connect **donors, conservation campaigns, donations and payment processes** in one simple user journey.
