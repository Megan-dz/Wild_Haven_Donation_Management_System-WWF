# 🐾 Wild Haven — Wildlife Conservation Donation Platform

> **Give a home to India's wild.**  
> A simple, visual donation website designed to help people understand where their contribution goes and make a conservation donation through a guided digital experience.

---

## 🌿 What is Wild Haven?

Wild Haven is a **wildlife conservation donation website**.

In simple terms, the website lets a visitor:

**Explore → Understand the mission → See where money can help → Choose a donation → Pay → Learn about the impact**

The website is designed around one main idea: **donors should understand what their money supports before they donate.**

---

## 🧭 How does the website work?

Think of Wild Haven like a digital conservation centre with a donation desk.

### 1️⃣ Explore the website

The homepage introduces Wild Haven and explains the conservation problem through a large visual section.

Visitors can immediately choose between:

- **Donate Now** — start the donation process
- **Learn More** — understand the organisation and its mission

The homepage also highlights headline impact figures such as protected land, rescue missions and supporters.

![Wild Haven donation homepage](images/05-home-donation.png)

---

### 2️⃣ Learn about the mission

The **Our Mission** section explains what Wild Haven is trying to achieve.

It presents conservation as more than simply protecting animals. The website highlights:

- 🐅 Species protection
- 🌳 Habitat restoration
- 🌏 Protection of fragile ecosystems
- 🤝 Coexistence between people and wildlife

The purpose of this section is to answer a simple donor question:

> **"Why should I support this organisation?"**

![Wild Haven mission](images/04-mission.png)

---

### 3️⃣ See where your donation can make an impact

The **Impact** section connects specific amounts of money with specific conservation activities.

For example:

| Donation | Example impact |
|---|---|
| ₹1,000 | Guard a Snow Leopard |
| ₹5,000 | Rescue an Elephant |
| ₹25,000 | Restore One Acre |

This makes the donation feel more tangible. Instead of simply seeing **"Donate ₹5,000"**, the visitor can see the conservation activity associated with that amount.

![Where your gift goes](images/02-impact.png)

---

### 4️⃣ Explore an individual campaign

When a visitor selects an impact area, they can open a dedicated campaign page.

For example, the **Guard a Snow Leopard** campaign explains:

- Why snow leopards need protection
- Where the conservation work takes place
- How a donation supports patrols
- How much of the campaign has been funded
- How much funding is still required

The campaign page also shows progress information such as the amount raised, the target and the percentage funded.

![Snow leopard campaign](images/06-campaign.png)

---

### 5️⃣ Choose how much to donate

The main donation interface allows the visitor to choose between:

- **One-Time** donation
- **Monthly** donation

The donor can select a predefined amount such as:

**₹500 · ₹1,000 · ₹2,500 · ₹5,000 · ₹10,000 · ₹25,000**

or enter a **custom amount**.

The page also displays the selected contribution and related tax-exemption information.

![Donation interface](images/03-donation-cta.png)

---

### 6️⃣ Continue to the payment page

After choosing the amount, the visitor moves to a dedicated checkout page.

The interface provides two payment routes:

- 💳 **Card**
- 📱 **UPI / QR**

For the card route, the user can enter:

- Name on card
- Card number
- Expiry
- CVV

The UPI / QR section displays a QR code and transaction information.

**Important:** the current interface explicitly identifies the checkout as a **demo checkout**, so no real payment is processed.

![Donation payment page](images/07-payment.png)

---

### 7️⃣ Find answers in the FAQ

The FAQ section answers common questions donors may have before contributing, including:

- Is my donation tax-deductible?
- How is my money used?
- Can I cancel my monthly donation?
- Are international donations accepted?

The questions are presented as expandable items, keeping the page clean while allowing users to reveal the answer they need.

![Frequently asked questions](images/01-faq.png)

---

# 🔄 The complete user journey

```text
                 ┌─────────────────┐
                 │   Visit Website │
                 └────────┬────────┘
                          │
                          ▼
                 ┌─────────────────┐
                 │ Explore Mission │
                 └────────┬────────┘
                          │
                          ▼
                 ┌─────────────────┐
                 │  View Impact    │
                 └────────┬────────┘
                          │
                ┌─────────┴─────────┐
                ▼                   ▼
       ┌────────────────┐   ┌─────────────────┐
       │ Choose Campaign│   │ Donate Directly │
       └───────┬────────┘   └────────┬────────┘
               │                     │
               └──────────┬──────────┘
                          ▼
                 ┌─────────────────┐
                 │ Choose Amount   │
                 │ One-time/Monthly│
                 └────────┬────────┘
                          │
                          ▼
                 ┌─────────────────┐
                 │ Payment / UPI   │
                 └────────┬────────┘
                          │
                          ▼
                 ┌─────────────────┐
                 │ Donation Journey│
                 │     Complete    │
                 └─────────────────┘
```

---

# 🧩 Main sections of the website

| Section | What the visitor does |
|---|---|
| 🏠 **Home** | Understands Wild Haven and starts exploring |
| 🌿 **Our Mission** | Learns about the conservation purpose |
| 📊 **Impact** | Sees how different donation amounts can be used |
| 🐆 **Campaign Pages** | Explores a specific conservation cause |
| 💰 **Donation** | Chooses one-time/monthly and selects an amount |
| 💳 **Payment** | Enters payment information or uses UPI / QR |
| ❓ **FAQ** | Gets answers to common donor questions |

---

# 💡 Why the website is designed this way

A donation website has one major challenge:

> **People need a reason to trust the organisation before they give money.**

Wild Haven addresses this by moving the visitor through three stages:

### ❤️ 1. Create an emotional connection

Wildlife imagery, conservation stories and statements about India's wild establish the purpose of the organisation.

### 🔎 2. Show where the money goes

The Impact section connects donation amounts with concrete conservation activities.

### 💳 3. Make donating simple

The donation interface reduces the decision to a few clear steps:

**Choose frequency → Choose amount → Continue → Pay**

This creates a straightforward donor journey rather than forcing the visitor to search around the website for information.

---

# 📈 Donation flow at a glance

```text
Visitor
   │
   ▼
Chooses "Donate Now"
   │
   ▼
Selects One-Time or Monthly
   │
   ▼
Selects ₹500 / ₹1,000 / ₹2,500 / ₹5,000 / ₹10,000 / ₹25,000
   │
   ├──► or enters a custom amount
   │
   ▼
Continues to donation
   │
   ▼
Card ───────────────► Card details
   │
   └── UPI / QR ─────► Scan to pay
```

---

# 🖼️ Website walkthrough

<details>
<summary><strong>🏠 Homepage</strong></summary>

The homepage is the main entry point. It introduces the conservation purpose and gives the visitor a direct route to donate or learn more.

![Homepage](images/05-home-donation.png)

</details>

<details>
<summary><strong>🌿 Our Mission</strong></summary>

This section explains the organisation's conservation focus and the types of work it supports.

![Mission](images/04-mission.png)

</details>

<details>
<summary><strong>📊 Impact</strong></summary>

Visitors can understand how different contribution levels are connected to conservation activities.

![Impact](images/02-impact.png)

</details>

<details>
<summary><strong>🐆 Campaign details</strong></summary>

A campaign page gives more information about a specific conservation objective and displays campaign progress.

![Campaign](images/06-campaign.png)

</details>

<details>
<summary><strong>💰 Donation selection</strong></summary>

The donation interface allows visitors to choose the contribution frequency and amount.

![Donation](images/03-donation-cta.png)

</details>

<details>
<summary><strong>💳 Payment</strong></summary>

The checkout provides Card and UPI / QR options. The current implementation is a demo checkout.

![Payment](images/07-payment.png)

</details>

<details>
<summary><strong>❓ FAQ</strong></summary>

The FAQ uses expandable questions so donors can quickly find information without making the page visually crowded.

![FAQ](images/01-faq.png)

</details>

---

# ✨ Key features

- 🐾 Wildlife-focused visual storytelling
- 🌿 Dedicated conservation mission section
- 📊 Impact-based donation options
- 🐆 Individual conservation campaign pages
- 💰 One-time and monthly donation options
- ✏️ Custom donation amount
- 💳 Card payment interface
- 📱 UPI / QR payment interface
- 📈 Campaign funding progress
- ❓ Expandable FAQ section
- 📱 Clear navigation between major sections
- 🎨 Consistent conservation-focused visual design

---

# 🧑‍💻 Project structure

A simple way to think about the website is:

```text
Wild Haven
│
├── Home
│   ├── Mission introduction
│   ├── Impact figures
│   └── Donate / Learn More
│
├── Our Mission
│   ├── Conservation purpose
│   ├── Species protection
│   └── Habitat restoration
│
├── Impact
│   ├── Donation amount
│   ├── Conservation activity
│   └── Campaign progress
│
├── Campaign
│   ├── Campaign story
│   ├── Funding progress
│   └── Donate
│
├── Donation
│   ├── One-Time
│   ├── Monthly
│   ├── Preset amounts
│   └── Custom amount
│
├── Payment
│   ├── Card
│   └── UPI / QR
│
└── FAQ
    └── Donor questions
```

---

# ⚠️ Current implementation note

This repository represents a **demonstration/prototype donation experience**.

The payment screen shown in the website states:

> **"This is a demo checkout. No real payment is processed."**

Therefore, the payment interface should be understood as a demonstration of the user experience rather than a live payment gateway.

---

# 🎯 In one sentence

**Wild Haven is a digital wildlife-conservation donation platform that takes a visitor from learning about conservation, to understanding the impact of their contribution, to selecting a donation and completing a demo payment.**

---

## 📚 Academic context

This website was developed as part of an academic project examining how **digital information systems can support donation management, donor engagement and organisational decision-making**.

The previous project documentation analysed donation platforms from an information-systems perspective, including Transaction Processing Systems (TPS), Management Information Systems (MIS), Decision Support Systems (DSS), enterprise systems and e-business platforms. fileciteturn0file0L56-L60

---

## 👥 Project team

- Megan Anriya Dcruz
- Agasthithayaagaran Saravanen
- Esha Naidu
- Anshuman Vasisht
- Uppalapati Harshith

---

## 📌 Note

The screenshots in this README correspond to the current Wild Haven website interface supplied for this project. The README describes the **visible user journey and functionality shown in the supplied website screenshots** rather than assuming additional backend functionality that is not visible in the interface.
